CREATE DATABASE IF NOT EXISTS employee_management;
USE employee_management;

CREATE TABLE IF NOT EXISTS employees (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    department VARCHAR(50) NOT NULL,
    designation VARCHAR(50) NOT NULL,
    salary DECIMAL(10,2) NOT NULL
);

INSERT INTO employees (name,email,department,designation,salary) VALUES
('Rahul Kumar','rahul@gmail.com','IT','Java Developer',35000),
('Priya Sharma','priya@gmail.com','HR','HR Executive',30000),
('Arun Kumar','arun@gmail.com','Finance','Accountant',32000);
