# Employee Management System

A beginner-to-intermediate Java console application for managing employee records with MySQL and JDBC.

## Features
- Add employee
- View all employees
- Search employee by ID
- Update employee
- Delete employee
- Search employees by department
- Input validation and exception handling

## Tech Stack
- Java 17
- Maven
- MySQL
- JDBC
- OOP
- Collections

## Project Structure
```text
EmployeeManagementSystem/
├── pom.xml
├── database/
│   └── employee_management.sql
└── src/main/java/com/ems/
    ├── Main.java
    ├── Employee.java
    ├── EmployeeDAO.java
    └── DBConnection.java
```

## Setup
1. Install JDK 17+, Maven and MySQL.
2. Run `database/employee_management.sql` in MySQL Workbench.
3. Open `DBConnection.java`.
4. Replace `YOUR_MYSQL_PASSWORD` with your MySQL password.
5. From the project root run:
   `mvn clean compile`
6. Run `com.ems.Main` from your IDE.

## Resume Description
Developed a Java-based Employee Management System using Core Java, OOP, JDBC and MySQL. Implemented CRUD operations, employee search, department filtering, input validation and exception handling. Used PreparedStatement for parameterized SQL operations and separated database logic using a DAO layer.

## Interview Topics
Java OOP, encapsulation, ArrayList/Collections, JDBC, PreparedStatement, ResultSet, CRUD, SQL, primary keys, exception handling and DAO pattern.
