package com.ems;

import java.util.List;
import java.util.Scanner;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final EmployeeDAO employeeDAO = new EmployeeDAO();

    public static void main(String[] args) {
        while (true) {
            displayMenu();
            int choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1 -> addEmployee();
                case 2 -> viewEmployees();
                case 3 -> searchEmployee();
                case 4 -> updateEmployee();
                case 5 -> deleteEmployee();
                case 6 -> searchByDepartment();
                case 7 -> {
                    System.out.println("Thank you for using Employee Management System.");
                    scanner.close();
                    return;
                }
                default -> System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void displayMenu() {
        System.out.println("\n======================================");
        System.out.println("      EMPLOYEE MANAGEMENT SYSTEM");
        System.out.println("======================================");
        System.out.println("1. Add Employee");
        System.out.println("2. View All Employees");
        System.out.println("3. Search Employee by ID");
        System.out.println("4. Update Employee");
        System.out.println("5. Delete Employee");
        System.out.println("6. Search by Department");
        System.out.println("7. Exit");
        System.out.println("======================================");
    }

    private static void addEmployee() {
        System.out.println("\n--- Add Employee ---");
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter email: ");
        String email = scanner.nextLine();
        System.out.print("Enter department: ");
        String department = scanner.nextLine();
        System.out.print("Enter designation: ");
        String designation = scanner.nextLine();
        double salary = readDouble("Enter salary: ");

        if (name.isBlank() || email.isBlank() || department.isBlank()
                || designation.isBlank() || salary <= 0) {
            System.out.println("Invalid employee details.");
            return;
        }

        if (employeeDAO.addEmployee(
                new Employee(name, email, department, designation, salary))) {
            System.out.println("Employee added successfully!");
        }
    }

    private static void viewEmployees() {
        System.out.println("\n--- Employee List ---");
        List<Employee> employees = employeeDAO.getAllEmployees();
        if (employees.isEmpty()) {
            System.out.println("No employees found.");
        } else {
            employees.forEach(System.out::println);
        }
    }

    private static void searchEmployee() {
        int id = readInt("Enter employee ID: ");
        Employee employee = employeeDAO.getEmployeeById(id);
        System.out.println(employee == null ? "Employee not found." : employee);
    }

    private static void updateEmployee() {
        System.out.println("\n--- Update Employee ---");
        int id = readInt("Enter employee ID: ");
        Employee existing = employeeDAO.getEmployeeById(id);
        if (existing == null) {
            System.out.println("Employee not found.");
            return;
        }

        System.out.print("Enter new name: ");
        String name = scanner.nextLine();
        System.out.print("Enter new email: ");
        String email = scanner.nextLine();
        System.out.print("Enter new department: ");
        String department = scanner.nextLine();
        System.out.print("Enter new designation: ");
        String designation = scanner.nextLine();
        double salary = readDouble("Enter new salary: ");

        Employee updated = new Employee(id, name, email, department, designation, salary);
        if (employeeDAO.updateEmployee(updated)) {
            System.out.println("Employee updated successfully!");
        }
    }

    private static void deleteEmployee() {
        int id = readInt("Enter employee ID: ");
        Employee employee = employeeDAO.getEmployeeById(id);
        if (employee == null) {
            System.out.println("Employee not found.");
            return;
        }

        System.out.println(employee);
        System.out.print("Are you sure? (yes/no): ");
        if (scanner.nextLine().equalsIgnoreCase("yes")) {
            System.out.println(employeeDAO.deleteEmployee(id)
                    ? "Employee deleted successfully!"
                    : "Delete failed.");
        } else {
            System.out.println("Delete operation cancelled.");
        }
    }

    private static void searchByDepartment() {
        System.out.print("Enter department: ");
        String department = scanner.nextLine();
        List<Employee> employees = employeeDAO.getEmployeesByDepartment(department);
        if (employees.isEmpty()) {
            System.out.println("No employees found.");
        } else {
            employees.forEach(System.out::println);
        }
    }

    private static int readInt(String message) {
        while (true) {
            try {
                System.out.print(message);
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid integer.");
            }
        }
    }

    private static double readDouble(String message) {
        while (true) {
            try {
                System.out.print(message);
                return Double.parseDouble(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }
}
